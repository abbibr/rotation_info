<?php

return [
    'home' => "Home",
];
