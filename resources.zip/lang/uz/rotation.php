<?php

return [
    'home' => "Bosh Sahifa",
    'service' => 'Service',
    'about' => 'About',
    'why_us' => 'Why us',
    'website' => 'Website',
    'faq' => 'FAQ',
    'contact' => 'Contact us',
    'work_solutions' => 'Work Solutions',
];
